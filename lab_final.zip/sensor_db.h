/**
* \author Shibo Liu
* aka. storagemgr
*/
#include "config.h"
#include "sbuffer.h"
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <pthread.h>

/**
* an operation to open a text file with a given name and provide an indication
* if the file should be overwritten(already exists) 
* if the data should be appended to the existing file
* append depends on whether the server is restarted or not
* if the server is restarted, it will overwritten the data.csv
* otherwise the data should append to data.csv
* \param sbuffer a pointer to the sbuffer, storagemgr fetches data from it
* \param append a bool indicates whether overwritten or not
*/
FILE *open_db(sbuffer_t* sbuffer, bool append);
/*
an operation to append a single sensor reading to the csv file
*/
int insert_sensor(FILE * f, sensor_id_t id, sensor_value_t value, sensor_ts_t ts);
/*
an operation to close the csv file
*/
int close_db(FILE * f);


