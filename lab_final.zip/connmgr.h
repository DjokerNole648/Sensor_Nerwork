#ifndef CONNMGR_H_
#define CONNMGR_H_

#include <pthread.h>
#include <time.h>
#include "sbuffer.h"
#include "config.h"
#include "lib/tcpsock.h"

#ifndef TIMEOUT
#error TIMEOUT not set
#endif

void connmgr_server(int PORT, sbuffer_t* sbuffer);

void* func(void* param);

void connmgr_log_event(char connmgr_log_event[MAX_LENGTH], int fd);

#endif  //CONNMGR_H_