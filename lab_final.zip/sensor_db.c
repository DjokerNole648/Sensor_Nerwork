/**
 * \author Shibo Liu
 * the storagemgr should check whether the data has been processed by the datamgr
*/
#include "sensor_db.h"
#define MAX_LENGTH 100

char open_existing[MAX_LENGTH] = "An existing file has been opened.";
char create_new[MAX_LENGTH] = "A new data.csv file has been created.";
char data_insert[MAX_LENGTH] = "Data insertion succeeded.";


FILE *open_db(sbuffer_t* sbuffer, bool append){
    FILE* fp_data;
    fopen(fp_data, "w");
    
}
int insert_sensor(FILE *f, sensor_id_t id, sensor_value_t value, sensor_ts_t ts){

}
int close_db(FILE *f){
    return fclose(f);
    //write to log-event file "The data.csv file has been closed."
}
