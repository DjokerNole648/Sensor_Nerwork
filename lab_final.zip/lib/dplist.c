/**
 * \author Shibo Liu
 */

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "dplist.h"

/*
 * definition of error codes
 * */
#define DPLIST_NO_ERROR 0
#define DPLIST_MEMORY_ERROR 1 // error due to mem alloc failure
#define DPLIST_INVALID_ERROR 2 //error due to a list operation applied on a NULL list 

#ifdef DEBUG
#define DEBUG_PRINTF(...) 									                                        \
        do {											                                            \
            fprintf(stderr,"\nIn %s - function %s at line %d: ", __FILE__, __func__, __LINE__);	    \
            fprintf(stderr,__VA_ARGS__);								                            \
            fflush(stderr);                                                                         \
                } while(0)
#else
#define DEBUG_PRINTF(...) (void)0
#endif

#define DPLIST_ERR_HANDLER(condition, err_code)                         \
    do {                                                                \
            if ((condition)) DEBUG_PRINTF(#condition " failed\n");      \
            assert(!(condition));                                       \
        } while(0)

struct dplist_node {
    dplist_node_t *prev, *next;
    void *element;
};

struct dplist {
    dplist_node_t *head;
    void* (*element_copy)(void *src_element);
    void (*element_free)(void **element);
    int (*element_compare)(void *x, void *y);
};


dplist_t *dpl_create(
        void* (*element_copy)(void *src_element),
        void (*element_free)(void **element),
        int (*element_compare)(void *x, void *y)
) {
    dplist_t *dp_list;
    dp_list = malloc(sizeof(struct dplist));
    DPLIST_ERR_HANDLER(dp_list == NULL, DPLIST_MEMORY_ERROR);
    dp_list->head = NULL;
    dp_list->element_copy = element_copy;
    dp_list->element_free = element_free;
    dp_list->element_compare = element_compare;
    return dp_list;
}

void dpl_free(dplist_t **list, bool free_element) {
    DPLIST_ERR_HANDLER((list == NULL || *list == NULL), DPLIST_MEMORY_ERROR);
    //if the head of the list is not NULL
    if(*list == NULL) return DPLIST_INVALID_ERROR;
    dplist_node_t *temp;
    temp = (*list)->head;
    while (temp != NULL) {
        //always delete the first element of the list
        dpl_remove_at_index(*list, 0, free_element);
        temp = (*list)->head;
    }
    free(*list);
    *list = NULL; //*list is head of the dplist, after the dplist is freed the head must be set to NULL
    
}

dplist_t *dpl_insert_at_index(dplist_t *list, void *element, int index, bool insert_copy) {
    dplist_node_t *ref_at_index, *list_node;
    //DPLIST_ERR_HANDLER(list == NULL, DPLIST_MEMORY_ERROR);
    list_node = malloc(sizeof(dplist_node_t));
    //DPLIST_ERR_HANDLER(list_node == NULL, DPLIST_MEMORY_ERROR);
    if(list == NULL) return NULL;
    // pointer drawing breakpoint
    if (insert_copy == true) list_node->element = list->element_copy(element);
    else list_node->element = element;
    //needs to be improved
    if (list->head == NULL) { // covers case 1
        list_node->prev = NULL;
        list_node->next = NULL;
        list->head = list_node;
        // pointer drawing breakpoint
    } else if (index <= 0) { // covers case 2
        list_node->prev = NULL;
        list_node->next = list->head;
        list->head->prev = list_node;
        list->head = list_node;
        // pointer drawing breakpoint
    } else {
        ref_at_index = dpl_get_reference_at_index(list, index);
        assert(ref_at_index != NULL);
        // pointer drawing breakpoint
        if (index < dpl_size(list)) { // covers case 4
            list_node->prev = ref_at_index->prev;
            list_node->next = ref_at_index;
            ref_at_index->prev->next = list_node;
            ref_at_index->prev = list_node;
            // pointer drawing breakpoint
        } else { // covers case 3
            assert(ref_at_index->next == NULL);
            list_node->next = NULL;
            list_node->prev = ref_at_index;
            ref_at_index->next = list_node;
            // pointer drawing breakpoint
        }
    }
    return list;
}

dplist_t *dpl_remove_at_index(dplist_t *list, int index, bool free_element) {
    dplist_node_t *dummy;
    if(list->head == NULL) return list;
    DPLIST_ERR_HANDLER(list == NULL, DPLIST_MEMORY_ERROR);
    dummy = dpl_get_reference_at_index(list, index);
    if(dummy->prev != NULL){	
		dummy->prev->next = dummy->next;
		if (dummy->next != NULL) dummy->next->prev = dummy->prev;
	}
	else {
		list->head = dummy->next;
		if (dummy->next != NULL) dummy->next->prev = dummy->prev;
	}
    if(free_element) list->element_free(&dummy->element);
    free(dummy);
    return list;
}

int dpl_size(dplist_t *list) {
    DPLIST_ERR_HANDLER(list == NULL, DPLIST_INVALID_ERROR);
    int count;
    dplist_node_t *dummy;
    if(list->head == NULL)  return NULL;
    /*
    * This for loop is modeled after the one in method 
    * dpl_get_reference_at_index in the source code
    */
    for (dummy = list->head, count = 0; dummy->next != NULL; dummy = dummy->next, count++);
    return count + 1;
}

void *dpl_get_element_at_index(dplist_t *list, int index) {
    DPLIST_ERR_HANDLER(list == NULL, DPLIST_INVALID_ERROR);
    dplist_node_t *dummy;
    if(list == NULL) return NULL;
    dummy = dpl_get_reference_at_index(list, index);
    return dummy->element;
}

int dpl_get_index_of_element(dplist_t *list, void *element) {
    if(list == NULL) return NULL;
    int count;
    dplist_node_t *dummy;
    DPLIST_ERR_HANDLER(list == NULL, DPLIST_INVALID_ERROR);
    for(dummy = list->head, count = 0; dummy != NULL; dummy = dummy->next, count++)
    {
        if (list->element_compare(dummy->element, element) == 0) return count;
    }
    return -1;
}

dplist_node_t *dpl_get_reference_at_index(dplist_t *list, int index) {
    int count;
    dplist_node_t *dummy;
    DPLIST_ERR_HANDLER(list == NULL, DPLIST_INVALID_ERROR);
    if (list->head == NULL) return NULL;
    for (dummy = list->head, count = 0; dummy->next != NULL; dummy = dummy->next, count++) {
        if (count >= index) return dummy;
    }
    return dummy;
}

void *dpl_get_element_at_reference(dplist_t *list, dplist_node_t *reference) {
    //if list is NULL, NULL is returned
    if(list == NULL) return NULL;
    dplist_node_t *dummy;
    DPLIST_ERR_HANDLER(list == NULL, DPLIST_INVALID_ERROR);
    //if the list is empty, NULL is returned
    if(list->head == NULL)  return NULL;
    //if the reference is NULL, NULL is returned
    if(reference == NULL)   return NULL;
    for(dummy = list->head; dummy != reference; dummy = dummy->next){
        if(reference == dummy) return dummy->element;
    }
    //if the reference is not an existing reference in the list, NULL is returned
    return NULL;
}


