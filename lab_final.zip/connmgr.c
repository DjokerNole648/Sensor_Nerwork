#include "connmgr.h"
#define MAX_LENGTH 100
#define TIMEOUT 5
char log_event[MAX_LENGTH];
int file_descriptor;
sbuffer_t* buffer;
sensor_data_t data;
time_t last_received_time;  // variable to store the time of the last received data
time_t current_time;  // variable to store the current time

void *func(void *param);

void connmgr_server(int PORT, sbuffer_t* sbuffer) {
    tcpsock_t *server, *client;
    int result;
    buffer = sbuffer;
    pthread_t pthread;
    
    printf("Test server is started\n");
    if (tcp_passive_open(&server, PORT) != TCP_NO_ERROR) exit(EXIT_FAILURE);
        while (1) {
            if (tcp_wait_for_connection(server, &client) != TCP_NO_ERROR) exit(EXIT_FAILURE);
            printf("Incoming client connection\n");
            sprintf(log_event, "Sensor node %d has opened a new connection", data.id);
            // initialize the last_received_time variable with the current time
            time(&last_received_time);
            pthread_create(&pthread, NULL, func, (void *)client);
            connmgr_log_event(log_event, file_descriptor);
            double time_diff = difftime(current_time, last_received_time);
            if(time_diff > TIMEOUT){
                //timeout, then close the client
                tcp_close(&client);
                //log event Sensor node <sensorNodeID> has closed the connection due to TIMEOUT
            }
            else{
                time(&last_received_time);
            } 
        } 

    if (tcp_close(&server) != TCP_NO_ERROR) exit(EXIT_FAILURE);
    printf("Test server is shutting down\n");
}

void *func(void *param){
    tcpsock_t *client = (tcpsock_t*) param;
    int result, bytes;
    do {
            // read sensor ID
            bytes = sizeof(data.id);
            result = tcp_receive(client, (void *) &data.id, &bytes);
            // read temperature
            bytes = sizeof(data.value);
            result = tcp_receive(client, (void *) &data.value, &bytes);
            // read timestamp
            bytes = sizeof(data.ts);
            result = tcp_receive(client, (void *) &data.ts, &bytes);
            if ((result == TCP_NO_ERROR) && bytes) {
                time(&current_time);// get the current time
                printf("sensor id = %" PRIu16 " - temperature = %g - timestamp = %ld\n", data.id, data.value,
                       (long int) data.ts);
                sbuffer_insert(buffer, &data);
            }
        } while (result == TCP_NO_ERROR);
        if (result == TCP_CONNECTION_CLOSED){
            printf("Peer has closed connection\n");
            sprintf(log_event, "Sensor node %d has closed the connection", data.id);
            connmgr_log_event(log_event, file_descriptor);
        } 
        else printf("Error occured on connection to peer\n");
        tcp_close(&client);
    return NULL;
}

void connmgr_log_event(char connmgr_log_event[MAX_LENGTH], int fd){
    file_descriptor = fd;
    write(fd, log_event, strlen(log_event)+1);
}

