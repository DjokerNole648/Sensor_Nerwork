#include "config.h"
#include "connmgr.h"
#include "datamgr.h"
#include "sbuffer.h"
#include "sensor_db.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>

#define MAX_LENGTH 100
#define READ_END 0
#define WRITE_END 1
/*
#define NEW_CONNECTION 2
#define TIMEOUT_CLOSE 3
#define CLOSE_CONNECTION 4
#define TOO_COLD 5
#define TOO_HOT 6
#define INVALID_ID 7
#define FILE_CREATED 8
#define INSERTION_SUCCEEDED 9
#define FILE_CLOSED 10
*/
void *connmgr(void *param);
void *datamgr(void *param);
void *storagemgr(void *param);

sbuffer_t *sbuffer;
//To make sure all the threads access to the pipe in a thread-safe manner, use mutex
pthread_mutex_t* pipe_mutex;
//conditional variables to broadcast that data is ready to be accessed by other pipes
pthread_cond_t* pipe_cond;
char* pipe_buffer[MAX_LENGTH];
int fd[2];
pid_t pid;
int sequence_number = 0;
int number;
int main(int argc, char* argv[]){
    if(argc < 2){
        printf("No extra command line argument passed other than program name.");
        return 1;
    }
    int PORT = atoi(argv[1]);
    //The main process runs three threads at startup
    pthread_t connmgr_thread, datamgr_thread, storagemgr_thread;
    sbuffer_init(&sbuffer);
    pthread_mutex_init(pipe_mutex, NULL);
    pthread_cond_init(pipe_cond, NULL);
    /*Create the pipe in the main process.
    RETURN VALUE
    On  success,  the PID of the child process is returned in the parent, and 0 is returned in the child.  On failure, -1 is returned in the parent, no child
    process is created, and errno is set appropriately.*/
    if (pipe(fd) == -1)
    {
        perror("pipe initialization failed");
        return 1;
    }
    pid = fork();
    if(pid < 0) fprintf(stderr, "fork failed");
    //main process
    else if(pid > 0){
        close(fd[0]);
     
        close(fd[1]);
    }
    //log process 
    else{
        FILE* fp_gateway;
        char* received[MAX_LENGTH];
        close(fd[1]);
        read(fd[0], received, strlen(received) + 1);
        close(fd[0]);
        //w mode for overwritten
        fp_gateway = fopen("gateway.log", "w");
        while(1)
        {
            sequence_number++;
            fprintf(fp_gateway, "%2d, %ld %s", sequence_number, time(NULL), received);
        }
        fclose(fp_gateway);
        exit(NULL);
    }
    pthread_create(&connmgr_thread, NULL, connmgr, &PORT);    
    pthread_create(&datamgr_thread, NULL, datamgr, NULL);
    pthread_create(&storagemgr_thread, NULL, storagemgr, NULL);
    pthread_join(connmgr, NULL);
    pthread_join(datamgr, NULL);
    pthread_join(storagemgr, NULL);
    sbuffer_free(&sbuffer);
    pthread_mutex_destroy(pipe_mutex);
    pthread_cond_destroy(pipe_cond);
    return 0;
}

void *connmgr(void *param){
    int PORT = *((int*)param);
    connmgr_server(PORT, sbuffer);
    //lock the mutex to gain exclusive access to the pipe
    pthread_mutex_lock(pipe_mutex);
    /*write to the pipe
    * sensor node <sensorNodeID> has opened a new connection
    * sensor node <sensorNodeID> has closed the connection
    * PUT THE WRITE TO THE PIPE FUNCTION HERE
    */
    pthread_cond_broadcast(pipe_cond);
    //unlock the mutex to allow other processes to access the pipe
    pthread_mutex_unlock(pipe_mutex);
    pthread_exit(NULL);
}

void *datamgr(void *param){
    pthread_mutex_lock(pipe_mutex);
    /*write to the pipe
    * sensor node <sensorNodeID> report it's too cold(avg temp = <value>)
    * sensor node <sensorNodeID> report it's too hot(avg temp = <value>)
    * received sensor data with invalid sensor node ID <sensorNodeID>
    * TODO: GENERAL IDEA
    * the sequence number is given in the main process and other information is given in each thread
    */
    pthread_cond_broadcast(pipe_cond);
    pthread_mutex_unlock(pipe_mutex);

    datamgr_parse_sensor_data(&sbuffer);
    datamgr_free();
    pthread_exit(NULL);
}

void *storagemgr(void *param){
    pthread_mutex_lock(pipe_mutex);
    /*write to the pipe
    * A new data.csv file has been created
    * Data insertion from sensor <sensorNodeID> succeeded
    * The data.csv file has been closed
    */
    pthread_cond_broadcast(pipe_cond);
    pthread_mutex_unlock(pipe_mutex);
}